package com.users.app.enums;

public enum Gender {
	MALE,
	FEMALE,
	OTHER;
	
}
