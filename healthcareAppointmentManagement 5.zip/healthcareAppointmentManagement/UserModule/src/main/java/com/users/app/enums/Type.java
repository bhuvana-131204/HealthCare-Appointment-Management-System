package com.users.app.enums;

public enum Type {
		Email,
		SMS,
		FrontEnd

}
