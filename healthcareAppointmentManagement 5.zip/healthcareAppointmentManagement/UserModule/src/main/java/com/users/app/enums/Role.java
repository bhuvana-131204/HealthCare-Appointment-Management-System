package com.users.app.enums;

public enum Role {
    DOCTOR,
    PATIENT;

}
