package com.users.app.enums;

public enum Status {
		Booked,
		Completed,
		Pending,
		Cancelled;
}
