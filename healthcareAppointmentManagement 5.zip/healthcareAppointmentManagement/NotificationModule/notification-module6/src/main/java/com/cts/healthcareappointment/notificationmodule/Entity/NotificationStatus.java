package com.cts.healthcareappointment.notificationmodule.Entity;

public enum NotificationStatus {
    Booked,
    Completed,
    Pending,
    Cancelled,
    Confirmed;
}

