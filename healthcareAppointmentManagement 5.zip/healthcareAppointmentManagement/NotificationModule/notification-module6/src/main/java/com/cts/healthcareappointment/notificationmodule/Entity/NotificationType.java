package com.cts.healthcareappointment.notificationmodule.Entity;


public enum NotificationType {
    APPOINTMENT, REMINDER, ALERT;
}
