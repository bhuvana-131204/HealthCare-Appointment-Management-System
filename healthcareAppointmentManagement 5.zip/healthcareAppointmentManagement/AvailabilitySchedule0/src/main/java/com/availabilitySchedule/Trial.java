/**
 * 
 * 
 * @author 2389585
 * @since Mar 25, 2025
 */
package com.availabilitySchedule;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Trial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list= Arrays.asList(1,2,3,4,5);
		for(int i:list ) {
			if(i%2==0) {
				System.out.println(""+i);
			}
			
		}
	}

}
